import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from risk_profile import TARGET,ACTIVE_WEIGHT,allocations,portfolio_stats
import pandas as pd
class TestStrategy(unittest.TestCase):
 def test_allocation(self):
  self.assertEqual(allocations(500),{'VOO':225.0,'VXUS':100.0,'VUG':75.0,'Active stock reserve':100.0})
  self.assertAlmostEqual(sum(TARGET.values())+ACTIVE_WEIGHT,1)
 def test_backtest_rejects_partial_weights(self):
  dates=pd.date_range('2020-01-31',periods=36,freq='ME')
  prices=pd.DataFrame({k:[100+i for i in range(36)] for k in TARGET},index=dates)
  with self.assertRaises(ValueError):portfolio_stats(prices,TARGET)
 def test_backtest_etf_only(self):
  dates=pd.date_range('2020-01-31',periods=36,freq='ME')
  prices=pd.DataFrame({k:[100+i for i in range(36)] for k in TARGET},index=dates)
  result=portfolio_stats(prices,{k:v/.8 for k,v in TARGET.items()},400)
  self.assertEqual(result['simulated_contributions'],400*35)
if __name__=='__main__':unittest.main()
